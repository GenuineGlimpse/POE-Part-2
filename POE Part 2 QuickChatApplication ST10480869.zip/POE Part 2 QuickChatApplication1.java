package quickchatapplication1;

import java.awt.HeadlessException;
import javax.swing.JOptionPane;
import java.util.Random;
import java.io.FileWriter;
import java.io.IOException;

public class QuickChatApplication1 {

    // User registration details
    static String savedUsername;
    static String savedPassword;
    static String savedPhoneNumber;

    // Message tracking
    static int sentMessageCount = 0;
    static int currentMessageNumber = 0;

    public static void main(String[] args) {

        JOptionPane.showMessageDialog(null,
                "Welcome to QuickChat!");

        registerAccount();

        boolean loggedIn = loginAccount();

        if (loggedIn) {
            JOptionPane.showMessageDialog(null,
                    "Login successful!");

            launchChatMenu();

        } else {
            JOptionPane.showMessageDialog(null,
                    "Incorrect login details. Application closing.");
        }
    }

    // =========================
    // USER REGISTRATION
    // =========================
    public static void registerAccount() {

        boolean registrationComplete = false;

        while (!registrationComplete) {

            // Username validation
            savedUsername = JOptionPane.showInputDialog(
                    "Create username:\nMust contain '_' and be 5 characters or less.");

            if (savedUsername == null || savedUsername.isEmpty()) {
                JOptionPane.showMessageDialog(null,
                        "Username cannot be empty.");
                continue;
            }

            if (!savedUsername.contains("_") || savedUsername.length() > 5) {
                JOptionPane.showMessageDialog(null,
                        "Invalid username format.");
                continue;
            }

            // Password validation
            savedPassword = JOptionPane.showInputDialog(
                    "Create password:\nMinimum 8 characters,\n1 capital letter,\n1 number,\n1 special character.");

            if (savedPassword == null || savedPassword.isEmpty()) {
                JOptionPane.showMessageDialog(null,
                        "Password cannot be empty.");
                continue;
            }

            if (!savedPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$")) {

                JOptionPane.showMessageDialog(null,
                        "Password does not meet requirements.");
                continue;
            }

            // Phone validation
            savedPhoneNumber = JOptionPane.showInputDialog(
                    "Enter South African cellphone number (+27xxxxxxxxx)");

            if (!savedPhoneNumber.matches("^\\+27[6-8]\\d{8}$")) {

                JOptionPane.showMessageDialog(null,
                        "Invalid cellphone number.");
                continue;
            }

            registrationComplete = true;
        }

        JOptionPane.showMessageDialog(null,
                "Registration completed successfully!");
    }

    // =========================
    // LOGIN SECTION
    // =========================
    public static boolean loginAccount() {

        String enteredUsername = JOptionPane.showInputDialog(
                "Enter username:");

        String enteredPassword = JOptionPane.showInputDialog(
                "Enter password:");

        return enteredUsername.equals(savedUsername)
                && enteredPassword.equals(savedPassword);
    }

    // =========================
    // MAIN MENU
    // =========================
    public static void launchChatMenu() {

        boolean applicationRunning = true;

        while (applicationRunning) {

            String[] menuOptions = {
                "Send Messages",
                "Coming Soon",
                "Exit"
            };

            int menuChoice = JOptionPane.showOptionDialog(
                    null,
                    "Select an option:",
                    "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    menuOptions,
                    menuOptions[0]
            );

            switch (menuChoice) {

                case 0 -> processMessages();

                case 1 -> JOptionPane.showMessageDialog(null,
                            "Feature coming soon.");

                case 2, -1 -> {
                    applicationRunning = false;

                    JOptionPane.showMessageDialog(null,
                            "Thank you for using QuickChat.");
                }
                default -> JOptionPane.showMessageDialog(null,
                        "Invalid selection.");
            }
        }
    }

    // =========================
    // MESSAGE PROCESSING
    // =========================
    public static void processMessages() {

        int numberOfMessages;

        try {

            numberOfMessages = Integer.parseInt(
                    JOptionPane.showInputDialog(
                            "How many messages would you like to send?")
            );

        } catch (HeadlessException | NumberFormatException e) {

            JOptionPane.showMessageDialog(null,
                    "Invalid number entered.");
            return;
        }

        for (int i = 0; i < numberOfMessages; i++) {

            currentMessageNumber++;

            String messageID = createMessageID();

            // Recipient validation
            String recipientNumber = JOptionPane.showInputDialog(
                    "Enter recipient number (+27xxxxxxxxx)");

            if (!recipientNumber.matches("^\\+27\\d{9}$")) {

                JOptionPane.showMessageDialog(null,
                        "Invalid recipient number.");

                i--;
                continue;
            }

            // Message input
            String messageText = JOptionPane.showInputDialog(
                    "Enter your message (Maximum 250 characters)");

            if (messageText.length() > 250) {

                int extraCharacters = messageText.length() - 250;

                JOptionPane.showMessageDialog(null,
                        "Message exceeds limit by "
                        + extraCharacters + " characters.");

                i--;
                continue;
            }

            // Generate hash
            String messageHash = buildMessageHash(
                    messageID,
                    currentMessageNumber,
                    messageText
            );

            // Message actions
            String[] actionOptions = {
                "Send",
                "Disregard",
                "Store"
            };

            int selectedAction = JOptionPane.showOptionDialog(
                    null,
                    "Choose an action:",
                    "Message Options",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    actionOptions,
                    actionOptions[0]
            );

            switch (selectedAction) {

                case 0 -> {
                    sentMessageCount++;

                    showMessageDetails(
                            messageID,
                            messageHash,
                            recipientNumber,
                            messageText
                    );

                    JOptionPane.showMessageDialog(null,
                            "Message sent successfully.");
                }

                case 1 -> JOptionPane.showMessageDialog(null,
                            "Message discarded.");

                case 2 -> {
                    saveMessageToJSON(
                            messageID,
                            messageHash,
                            recipientNumber,
                            messageText
                    );

                    JOptionPane.showMessageDialog(null,
                            "Message stored successfully.");
                }
            }
        }

        JOptionPane.showMessageDialog(null,
                "Total messages sent: " + sentMessageCount);
    }

    // =========================
    // GENERATE MESSAGE ID
    // =========================
    public static String createMessageID() {

        Random random = new Random();

        return String.format("%010d",
                random.nextInt(1_000_000_000));
    }

    // =========================
    // CREATE HASH
    // =========================
    public static String buildMessageHash(
            String id,
            int messageNumber,
            String message) {

        String[] words = message.trim().split(" ");

        String firstWord = words[0];
        String lastWord = words[words.length - 1];

        return (id.substring(0, 2)
                + ":" + messageNumber
                + ":" + firstWord
                + lastWord).toUpperCase();
    }

    // =========================
    // DISPLAY MESSAGE DETAILS
    // =========================
    public static void showMessageDetails(
            String id,
            String hash,
            String recipient,
            String message) {

        JOptionPane.showMessageDialog(null,
                "Message ID: " + id
                + "\nMessage Hash: " + hash
                + "\nRecipient: " + recipient
                + "\nMessage: " + message);
    }

    // =========================
    // STORE MESSAGE IN JSON
    // =========================
    public static void saveMessageToJSON(
            String messageID,
            String hash,
            String recipient,
            String message) {

        StringBuilder json = new StringBuilder();

        json.append("{\n");
        json.append("\"MessageID\": \"").append(messageID).append("\",\n");
        json.append("\"MessageHash\": \"").append(hash).append("\",\n");
        json.append("\"Recipient\": \"").append(recipient).append("\",\n");
        json.append("\"Message\": \"")
                .append(message.replace("\"", "\\\""))
                .append("\"\n");
        json.append("},\n");

        try (FileWriter writer = new FileWriter("messages.json", true)) {

            writer.write(json.toString());

        } catch (IOException error) {

            JOptionPane.showMessageDialog(null,
                    "Error saving message: "
                    + error.getMessage());
        }
    }
}